/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author carloscarrascal
 */
public class Inventarios {
    
    private String cantidad;
    private String id_producto;
    private String codigo_almacen;

    public Inventarios(String cantidad, String id_producto, String codigo_almacen) {
        this.cantidad = cantidad;
        this.id_producto = id_producto;
        this.codigo_almacen = codigo_almacen;
    }

    public String getCodigo_almacen() {
        return codigo_almacen;
    }

    public void setCodigo_almacen(String codigo_almacen) {
        this.codigo_almacen = codigo_almacen;
    }

    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

   
   
}
