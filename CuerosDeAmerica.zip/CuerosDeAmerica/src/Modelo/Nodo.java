package Modelo;

/**
 *
 * @author netosolis.com
 */
public class Nodo {
    private int posicion;
    private int id;
    private Nodo izq,der;
    public Nodo(int posicion, int id){
        this.posicion = posicion;
        this.id = id;
        izq = null;
        der = null;
    }

    public int getPosicion() {
        return posicion;
    }
    
    public int getID() {
        return id;
    }

    public Nodo getIzq() {
        return izq;
    }

    public Nodo getDer() {
        return der;
    }

    public void setDato(int posicion, int id) {
        this.posicion = posicion;
        this.id = id;
    }

    public void setIzq(Nodo izq) {
        this.izq = izq;
    }

    public void setDer(Nodo der) {
        this.der = der;
    } 
}
