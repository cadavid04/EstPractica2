package Modelo;

import java.util.LinkedList;

/**
 *
 * @author netosolis.com
 */
public class ArbolBinario {
    private Nodo raiz;
    private int num_nodos;
    private int alt;

    public ArbolBinario() {
        raiz = null;
        num_nodos = 0;
        alt = 0;
    }
    
    //Metodo para insertar un dato en el arbol...no acepta repetidos :)
    public void insertar(int pocicion, int id){
       if(existe(id))return;
       Nodo nuevo = new Nodo(pocicion, id);
          if (raiz == null)
              raiz = nuevo;
          else
          {
              Nodo anterior = null;
              Nodo tmp = raiz;
              while (tmp != null)
              {
                  anterior = tmp;
                  if (id < tmp.getID())
                      tmp = tmp.getIzq();
                  else
                      tmp = tmp.getDer();
              }
              if (id < anterior.getID())
                  anterior.setIzq(nuevo);
              else
                  anterior.setDer(nuevo);
          }
          num_nodos++;
    }

    public Nodo getRaiz() {
        return raiz;
    }

    public void setRaiz(Nodo raiz) {
        this.raiz = raiz;
    }

    public int getNumNodos() {
        return num_nodos;
    }
 
    
    //Metodo para verificar si hay un nodo en el arbol
    public boolean existe(int id) {
        Nodo aux = raiz;
        while (aux!=null) {
            if (id==aux.getID())
                return true;
            else
                if (id>aux.getID())
                    aux=aux.getDer();
                else
                    aux=aux.getIzq();
        }
        return false;
    }
    
    
    private void altura (Nodo aux,int nivel)  {
        if (aux != null) {    
            altura(aux.getIzq(),nivel+1);
            alt = nivel;
            altura(aux.getDer(),nivel+1);
        }
    }
    //Devuleve la altura del arbol
    public int getAltura(){
        altura(raiz,1);
        return alt;
    }
     
}
