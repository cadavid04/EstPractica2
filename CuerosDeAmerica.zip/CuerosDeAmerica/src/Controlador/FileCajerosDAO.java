/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author carloscarrascal
 */


import Modelo.ArbolBinario;
import static java.nio.file.StandardOpenOption.APPEND;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import Modelo.Cajeros;
import javax.swing.JOptionPane;

public class FileCajerosDAO implements CajerosDAO {
    


	private static final String NOMBRE_ARCHIVO = "Cajeros";
	private static final Path file= Paths.get(NOMBRE_ARCHIVO);
	private static final int LONGITUD_REGISTRO = 185;
	private static final int ID_CAJERO_LONGITUD = 20;
	private static final int NOMBRES_LONGITUD = 20;
        private static final int APELLIDOS_LONGITUD = 20;
        private static final int CORREO_LONGITUD = 25;
        private static final int GENERO_LONGITUD = 20;
        private static final int CELULAR_LONGITUD = 20;
        private static final int FECHA_INGRESO_LONGITUD = 20;
	private static final int CONTRASENA_LONGITUD = 20;
        private static final int ESTADO_LONGITUD = 20;
	
	
	private static final Map<String, Cajeros> CACHE_CAJEROS = new HashMap<String, Cajeros>();
        ArbolBinario abCajero = new ArbolBinario();
        
        @Override
        public ArbolBinario getArbol(){
            return abCajero;
        }
        
        
           public FileCajerosDAO() {
		if (!Files.exists(file)) {
			try {
				Files.createFile(file);
			} catch (IOException e) {
				// TODO notificar con una excepci�n al negocio
				e.printStackTrace();
			}
		}
		crearIndice();
	}
           
           private void crearIndice() {
		System.out.println("Creando el índice de cajeros...");
		try (SeekableByteChannel sbc = Files.newByteChannel(file)) {
			ByteBuffer buf = ByteBuffer.allocate(LONGITUD_REGISTRO);		
			String encoding = System.getProperty("file.encoding");
			int posicion=0;
			while (sbc.read(buf) > 0) {
				buf.rewind();
				CharBuffer registro = Charset.forName(encoding).decode(buf);
				String identificacion = registro.subSequence(0, ID_CAJERO_LONGITUD).toString().trim();
				abCajero.insertar(posicion++, Integer.parseInt(identificacion));
				buf.flip();
			}
		} catch (IOException x) {
			System.out.println("caught exception: " + x);
		}

	}
	
//Método para registrar cajeros
	@Override
	public boolean saveCajero(Cajeros cajero) {
                int id = Integer.parseInt(cajero.getId_cajero());
                int posicion = abCajero.getNumNodos() + 1;
                if(abCajero.existe(id)){
                   JOptionPane.showMessageDialog(null, "El ID ya se encuentra registrado");
                   return false; 
                } else {
                       abCajero.insertar(posicion, id);
                       String registro=parseCajerosString(cajero);
                       byte data[] = registro.getBytes();
                       ByteBuffer out = ByteBuffer.wrap(data);	
                       try (FileChannel fc = (FileChannel.open(file, APPEND))) {
			fc.write(out);
			return true;
                        } catch (IOException x) {
			System.out.println("I/O Exception: " + x);
		}
		return false;}
	}
	
//Método para buscar cajeros	
	@Override
	public Cajeros getCajeros(String id_cajero) {
		//se busca el objeto en memoria cach�
		Cajeros cajero = CACHE_CAJEROS.get(id_cajero);
		
		if(cajero!=null){
			System.out.println("ocurrió un hit en caché de cajeros");//contraejemplo, no hacer, no recomendable, usar Logger como log4J
			return cajero; //ocurri� un hit de cach�
		}
		System.out.println("ocurrió un miss en caché de cajeros");
		//ocurrió un miss de caché
		try (SeekableByteChannel sbc = Files.newByteChannel(file)) {
		    ByteBuffer buf = ByteBuffer.allocate(LONGITUD_REGISTRO);		    
		    // Se utiliza la propiedad del sistema que indica la codificaci�n de los archivos 
		    String encoding = System.getProperty("file.encoding");
		    while (sbc.read(buf) > 0) {
		        buf.rewind();
		        CharBuffer registro= Charset.forName(encoding).decode(buf);
		        String identificacion = registro.subSequence(0, ID_CAJERO_LONGITUD).toString().trim();
		        if(identificacion.equals(id_cajero)){
		        	cajero = parseCajero(registro);
		        	CACHE_CAJEROS.put(id_cajero, cajero);
		        	return cajero;
		        }
		        buf.flip();		        		        
		    }
		} catch (IOException x) {
		    System.out.println("caught exception: " + x);
		}
		return null;		
	}

	

//Método para listar todos los cajeros	
	@Override
	public List<Cajeros> getAllCajeros() {	
		List<Cajeros> cajeros = new ArrayList<Cajeros>();
		try (SeekableByteChannel sbc = Files.newByteChannel(file)) {
		    ByteBuffer buf = ByteBuffer.allocate(LONGITUD_REGISTRO);  
		    String encoding = System.getProperty("file.encoding");
		    while (sbc.read(buf) > 0) {
		        buf.rewind();
		        Cajeros cajero = parseCajero(Charset.forName(encoding).decode(buf));
		        buf.flip();
		        cajeros.add(cajero);		        
		    }
		} catch (IOException x) {
		    System.out.println("caught exception: " + x);
		}
		return cajeros;
	}
		

//Método para convertir CharBuffer a objeto Cajero
	private Cajeros parseCajero(CharBuffer registro){		
		String id_cajero = registro.subSequence(0, ID_CAJERO_LONGITUD ).toString();
		registro.position(ID_CAJERO_LONGITUD);
		registro=registro.slice();
				
		String nombres = registro.subSequence(0, NOMBRES_LONGITUD).toString();
		registro.position(NOMBRES_LONGITUD);	
		registro=registro.slice();	
                
                String apellidos = registro.subSequence(0, APELLIDOS_LONGITUD).toString();
		registro.position(APELLIDOS_LONGITUD);	
		registro=registro.slice();
                
                String correo = registro.subSequence(0, CORREO_LONGITUD).toString();
		registro.position(CORREO_LONGITUD);	
		registro=registro.slice();
                
                String celular = registro.subSequence(0, CELULAR_LONGITUD).toString();
		registro.position(CELULAR_LONGITUD);	
		registro=registro.slice();
                
                String genero = registro.subSequence(0, GENERO_LONGITUD).toString();
		registro.position(GENERO_LONGITUD);	
		registro=registro.slice();
                
                String fecha_ingreso = registro.subSequence(0, FECHA_INGRESO_LONGITUD).toString();
		registro.position(FECHA_INGRESO_LONGITUD);	
		registro=registro.slice();
		
		String contrasena = registro.subSequence(0, CONTRASENA_LONGITUD).toString();
		registro.position(CONTRASENA_LONGITUD);	
		registro=registro.slice();
                
                String estado = registro.subSequence(0, ESTADO_LONGITUD).toString();
		registro.position(ESTADO_LONGITUD);	
		registro=registro.slice();
		
		
		Cajeros c = new Cajeros(id_cajero, nombres, apellidos, correo, celular, genero, fecha_ingreso, contrasena, estado);
		return c;
	}
//Método para convertir objeto Cajero a String	
	private String parseCajerosString(Cajeros cajero){
		StringBuilder registro = new StringBuilder(LONGITUD_REGISTRO);
		registro.append(completarCampoConEspacios(cajero.getId_cajero(),ID_CAJERO_LONGITUD));
		registro.append(completarCampoConEspacios(cajero.getNombre(), NOMBRES_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getApellido(), APELLIDOS_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getCorreo_e(), CORREO_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getCelular(), CELULAR_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getGenero(), GENERO_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getFecha_ingreso(), FECHA_INGRESO_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getContrasena(), CONTRASENA_LONGITUD));
                registro.append(completarCampoConEspacios(cajero.getEstado(), ESTADO_LONGITUD));
			
		return registro.toString();
	}
	
	/**
	 * Rellena con espacios a la derecha el String que se env�e como par�metro. Si el tama�o del String
	 * supera el valor del tama�o que se env�a como par�metro, se ajusta el contenido del String a dicho tama�o
	 * @param campo, tamanio
	 * @return String
	 */
	private String completarCampoConEspacios(String campo, int tamanio){
		if(campo.length()>tamanio){//Ser responsable y lanzar una excepci�n
			campo=campo.substring(0, tamanio);
			return campo;
		}
		return String.format("%1$-" + tamanio + "s", campo);
	}


}
/**
 *
 * @author carloscarrascal
 */