/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author carloscarrascal
 */
import Modelo.ArbolBinario;
import java.util.List;
import Modelo.Clientes;

public interface ClientesDAO {
	public ArbolBinario getArbol();
	public Clientes getClientes(String id_cliente);
	public boolean saveCliente (Clientes cliente);
	public List<Clientes> getAllClientes();
        public List<Clientes> getAllClientesAb();
	
}
