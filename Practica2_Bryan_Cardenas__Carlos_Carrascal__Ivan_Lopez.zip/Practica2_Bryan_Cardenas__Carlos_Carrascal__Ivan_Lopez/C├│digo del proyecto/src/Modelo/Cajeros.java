/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;

/**
 *
 * @author carloscarrascal
 */
public class Cajeros {
    
     
    private String id_cajero;
    private String nombre;
    private String apellido;
    private String correo_e;
    private String celular;
    private String genero;
    private String fecha_ingreso;
    private String contrasena;
    private String estado;
    private List <Ventas> ventas;



    public Cajeros(String id_cajero, String nombre, String apellido, String correo_e, String celular, String genero, String fecha_ingreso, String contrasena, String estado) {
        this.id_cajero = id_cajero;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo_e = correo_e;
        this.celular = celular;
        this.genero = genero;
        this.fecha_ingreso = fecha_ingreso;
        this.contrasena = contrasena;
        this.estado = estado;
    }

    public Cajeros() {
        
    }

    public void setId_cajero(String id_cajero) {
        this.id_cajero = id_cajero;
    }

        public String getId_cajero() {
        return id_cajero;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo_e() {
        return correo_e;
    }

    public void setCorreo_e(String correo_e) {
        this.correo_e = correo_e;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContraseña(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public List <Ventas> getVentas() {
        return ventas;
    }

    public void setVentas(List <Ventas> ventas) {
        this.ventas = ventas;
    }
    
}
