/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.CajerosDAO;
import Controlador.VentasDAO;
import Modelo.Ventas;
import Modelo.Clientes;
import Controlador.FileVentasDAO;
import javax.swing.JOptionPane;
import Controlador.ClientesDAO;
import Controlador.FileCajerosDAO;
import Controlador.FileClientesDAO;
import Controlador.FileProductosDAO;
import Controlador.ProductosDAO;
import Modelo.ArbolBinario;
import Modelo.Cajeros;
import Modelo.Nodo;
import Modelo.Productos;
import java.awt.Color;
import java.awt.Graphics;
import java.util.List;



/**
 *
 * @author carloscarrascal
 */
public class VistaVentas extends javax.swing.JFrame {
    
    Ventas v;
    VentasDAO vDAO = new FileVentasDAO();
    Cajeros c = new Cajeros();
    CajerosDAO cADAO = new FileCajerosDAO();
    ClientesDAO clADAO = new FileClientesDAO();
    ArbolBinario abCajeros = cADAO.getArbol();
    ArbolBinario abClientes = clADAO.getArbol();
    ArbolBinario ab = vDAO.getArbol();
    
       public String getConsecutivo (){
             {
             try{String consecutivo = txtConsecutivo.getText();
                return consecutivo;
             }catch(Exception ex){
           return "Error";
                        }
                    }
       }
      public String getCliente (){
                {
                try{String cliente = jCbxIdCliente.getSelectedItem().toString();
                    return cliente;
                }catch(Exception ex){
                return "Error";
                    }
                }
        }
             public String getCajero (){
                {
                try{String cajero = jCbxIdCajero.getSelectedItem().toString();
                    return cajero;
                }catch(Exception ex){
                return "Error";
                    }
                }
        }
         
         public String getValorBruto(){
                {
                 try{String valorBruto = txtValorBruto.getText();
                    return valorBruto;
                }catch(Exception ex){
                return "Error";
                                            }
                }
         }
         public String getDescuentos (){
                {
                 try{String descuentos = txtDescuentos.getText();
                    return descuentos;
                }catch(Exception ex){
                return "Error";
                        }
                    }
        }

         public String getValorNeto(){
                {
                 try{int valorBruto = Integer.parseInt(txtValorBruto.getText());
                     int valorDescuento = Integer.parseInt(txtDescuentos.getText());
                     int valorNeto = valorBruto - valorDescuento;
                     String valor = Integer.toString(valorNeto);
                     txtValorNeto.setText(valor);
                 
                    return valor;
                }catch(Exception ex){
                return "Error";
                        }
                    }
        }

         
         public String getFecha (){
                {
                 try{String fecha = txtFecha.getText();
                    return fecha;
                }catch(Exception ex){
                return "Error";
                                            }
                }
         }
           public String getHora(){
                {
                 try{String hora = txtHora.getText();
                    return hora;
                }catch(Exception ex){
                return "Error";
                                            }
                }
         }
         
          public String getMedio (){
                {
                 try{String medio = txtMedio.getText();
                    return medio;
                }catch(Exception ex){
                return "Error";
                                            }
                }
         }
         
          
         
      public void registrarVenta(){
      
      v= new Ventas( getConsecutivo(), getCliente(),getCajero(),getValorBruto(),getDescuentos(),getValorNeto(), getFecha(), getHora(), getMedio());
      if (vDAO.saveVenta(v)) {
            JOptionPane.showMessageDialog(null, "Se ha registrado correctamente la venta");
            } else{
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error. Contacte al administrador");
                }
      }
      
       private void pintaArbol(Graphics g, Nodo n, int x, int y,int xoff,int yoff,int nivel){
         if (n == null) return;
            g.setColor(Color.black);
         if(n.getIzq()!= null){
            g.drawLine(x, y, x - xoff+(nivel*2), y + yoff);
            }      
         if(n.getDer()!= null){
            g.drawLine(x, y, x + xoff-(nivel*2), y + yoff);
            }
     
            g.fillOval(x-10, y-20, 30, 30);
     
            g.setColor(Color.white);
            g.drawString(n.getID()+" ", x , y );
     
            pintaArbol(g, n.getIzq(), (int)(x - xoff), (y + yoff),xoff+nivel*2,yoff,nivel+1);
            pintaArbol(g, n.getDer(), (int)(x + xoff), (y + yoff),xoff-nivel*2,yoff,nivel+1);
}
    @Override
    public void paint(Graphics g){
        jPanelArbolVentas.revalidate();
        super.paint(g);
        int X = (getWidth()/5)*ab.getAltura();
        int X2 = (getWidth()/12);
        int Y = getHeight()/12;
        pintaArbol(jPanelArbolVentas.getGraphics(), ab.getRaiz(), jPanelArbolVentas.getWidth()/2, Y, X2, Y,1);
        
    }

    /**
     * Creates new form VistaProductos
     */
    public VistaVentas() {
        initComponents();
       
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtConsecutivo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtValorBruto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDescuentos = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtHora = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtMedio = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtValorNeto = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jCbxIdCliente = new javax.swing.JComboBox<>();
        jCbxIdCajero = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanelArbolVentas = new javax.swing.JPanel();

        txtConsecutivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsecutivoActionPerformed(evt);
            }
        });

        jLabel1.setText("Id cajero");

        jLabel2.setText("Id cliente");

        jLabel3.setText("Consecutivo");

        jLabel4.setText("Valor bruto");

        jLabel5.setText("Descuentos");

        txtDescuentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescuentosActionPerformed(evt);
            }
        });

        jButton1.setText("Registrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setText("Hora");

        txtHora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraActionPerformed(evt);
            }
        });

        jLabel7.setText("Medio de p.");

        txtMedio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMedioActionPerformed(evt);
            }
        });

        jLabel9.setText("Valor neto");

        txtValorNeto.setEditable(false);
        txtValorNeto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValorNetoActionPerformed(evt);
            }
        });

        jLabel10.setText("Fecha");

        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });

        jCbxIdCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        ClientesDAO ciDAO = new FileClientesDAO();
        List<Clientes> listClientes= ciDAO.getAllClientesAb();

        int k=0;
        for (k=0;k <listClientes.size();k++){
            jCbxIdCliente.addItem(listClientes.get(k).getId_cliente());
        }
        jCbxIdCliente.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCbxIdClienteItemStateChanged(evt);
            }
        });
        jCbxIdCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCbxIdClienteActionPerformed(evt);
            }
        });

        jCbxIdCajero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        CajerosDAO caDAO = new FileCajerosDAO();
        List<Cajeros> listCajeros= caDAO.getAllCajerosAb();

        int i=0;
        for (i=0;i <listCajeros.size();i++){
            jCbxIdCajero.addItem(listCajeros.get(i).getId_cajero());
        }

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        ProductosDAO piDAO = new FileProductosDAO();
        List<Productos> listProductos= piDAO.getAllProductosAb();

        int j=0;
        for (j=0;j <listProductos.size();j++){
            jComboBox1.addItem(listProductos.get(j).getId_productos());
        }

        jLabel8.setText("Productos");

        jButton2.setText("Menu");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/ImgVentas.png")));

        javax.swing.GroupLayout jPanelArbolVentasLayout = new javax.swing.GroupLayout(jPanelArbolVentas);
        jPanelArbolVentas.setLayout(jPanelArbolVentasLayout);
        jPanelArbolVentasLayout.setHorizontalGroup(
            jPanelArbolVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanelArbolVentasLayout.setVerticalGroup(
            jPanelArbolVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 154, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2)
                                .addComponent(jLabel8)
                                .addComponent(jLabel3))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMedio, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtConsecutivo)
                                .addComponent(jCbxIdCliente, 0, 186, Short.MAX_VALUE)
                                .addComponent(jCbxIdCajero, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtValorNeto, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtValorBruto)
                                    .addComponent(txtDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addComponent(jPanelArbolVentas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(86, 86, 86)
                        .addComponent(jButton2)
                        .addGap(85, 85, 85))))
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtConsecutivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(jCbxIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(jCbxIdCajero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(txtMedio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtValorBruto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtValorNeto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(12, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanelArbolVentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDescuentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescuentosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescuentosActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.registrarVenta();
        paint(jPanelArbolVentas.getGraphics());
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtHoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraActionPerformed

    private void txtMedioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMedioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMedioActionPerformed

    private void txtConsecutivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsecutivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsecutivoActionPerformed

    private void txtValorNetoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValorNetoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtValorNetoActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void jCbxIdClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCbxIdClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCbxIdClienteActionPerformed

    private void jCbxIdClienteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCbxIdClienteItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jCbxIdClienteItemStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaVentas().setVisible(true);
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jCbxIdCajero;
    private javax.swing.JComboBox<String> jCbxIdCliente;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelArbolVentas;
    private javax.swing.JTextField txtConsecutivo;
    private javax.swing.JTextField txtDescuentos;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtMedio;
    private javax.swing.JTextField txtValorBruto;
    private javax.swing.JTextField txtValorNeto;
    // End of variables declaration//GEN-END:variables
}
