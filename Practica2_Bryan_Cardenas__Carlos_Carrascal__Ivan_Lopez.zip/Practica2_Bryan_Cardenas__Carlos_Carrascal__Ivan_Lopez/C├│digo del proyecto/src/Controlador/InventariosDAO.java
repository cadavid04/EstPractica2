/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author carloscarrascal
 */
import Modelo.ArbolBinario;
import Modelo.Inventarios;
import java.util.List;



public interface InventariosDAO {
	
        
	public boolean saveInventarios (Inventarios inventario);
	public List<Inventarios> getAllInventarios();
	
}
